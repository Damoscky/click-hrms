<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="" />
    <meta name="keywords"
        content="" />
    <meta name="author" content="Dreamguys - Bootstrap Admin Template" />
    <title>Dashboard || <?php echo e(env('APP_NAME')); ?></title>

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets')); ?>/img/favicon.png" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/bootstrap.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/fontawesome/css/fontawesome.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/fontawesome/css/all.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/line-awesome.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/material.css" />


    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/bootstrap.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/dataTables.bootstrap4.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/select2.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/bootstrap-datetimepicker.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/morris/morris.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/style.css" />
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyApcI-eCy2vhDU9Fx4GmhKsysL8xoZ69oU&libraries=places"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>
    <div class="main-wrapper">
        <div class="header">
            <div class="header-left">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="logo">
                    <img src="<?php echo e(asset('assets')); ?>/img/clickhrm-logo.png" width="40" height="40"
                        alt="Logo" />
                </a>
                <a href="admin-dashboard.html" class="logo2">
                    <img src="<?php echo e(asset('assets')); ?>/img/clickhrm-logo.png" width="40" height="40"
                        alt="Logo" />
                </a>
            </div>

            <a id="toggle_btn" href="javascript:void(0);">
                <span class="bar-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            </a>

            

            <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa-solid fa-bars"></i></a>

            <ul class="nav user-menu">

                <li class="nav-item dropdown">
                    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                        <i class="fa-regular fa-bell"></i>
                        <span class="badge rounded-pill">3</span>
                    </a>
                    <div class="dropdown-menu notifications">
                        <div class="topnav-dropdown-header">
                            <span class="notification-title">Notifications</span>
                            <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
                        </div>
                        <div class="noti-content">
                            <ul class="notification-list">
                                <li class="notification-message">
                                    <a href="activities.html">
                                        <div class="chat-block d-flex">
                                            <span class="avatar flex-shrink-0">
                                                <img src="<?php echo e(asset('assets')); ?>/img/profiles/avatar-02.jpg"
                                                    alt="User Image" />
                                            </span>
                                            <div class="media-body flex-grow-1">
                                                <p class="noti-details">
                                                    <span class="noti-title">John Doe</span> added new
                                                    task
                                                    <span class="noti-title">Patient appointment booking</span>
                                                </p>
                                                <p class="noti-time">
                                                    <span class="notification-time">4 mins ago</span>
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li class="notification-message">
                                    <a href="activities.html">
                                        <div class="chat-block d-flex">
                                            <span class="avatar flex-shrink-0">
                                                <img src="<?php echo e(asset('assets')); ?>/img/profiles/avatar-03.jpg"
                                                    alt="User Image" />
                                            </span>
                                            <div class="media-body flex-grow-1">
                                                <p class="noti-details">
                                                    <span class="noti-title">Tarah Shropshire</span>
                                                    changed the task name
                                                    <span class="noti-title">Appointment booking with payment
                                                        gateway</span>
                                                </p>
                                                <p class="noti-time">
                                                    <span class="notification-time">6 mins ago</span>
                                                </p>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="topnav-dropdown-footer">
                            <a href="activities.html">View all Notifications</a>
                        </div>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                        <i class="fa-regular fa-comment"></i><span class="badge rounded-pill">8</span>
                    </a>
                    <div class="dropdown-menu notifications">
                        <div class="topnav-dropdown-header">
                            <span class="notification-title">Messages</span>
                            <a href="javascript:void(0)" class="clear-noti"> Clear All </a>
                        </div>
                        <div class="noti-content">
                            <ul class="notification-list">
                                <li class="notification-message">
                                    <a href="chat.html">
                                        <div class="list-item">
                                            <div class="list-left">
                                                <span class="avatar">
                                                    <img src="<?php echo e(asset('assets')); ?>/img/profiles/avatar-09.jpg"
                                                        alt="User Image" />
                                                </span>
                                            </div>
                                            <div class="list-body">
                                                <span class="message-author">Richard Miles </span>
                                                <span class="message-time">12:28 AM</span>
                                                <div class="clearfix"></div>
                                                <span class="message-content">Lorem ipsum dolor sit amet, consectetur
                                                    adipiscing</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li class="notification-message">
                                    <a href="chat.html">
                                        <div class="list-item">
                                            <div class="list-left">
                                                <span class="avatar">
                                                    <img src="<?php echo e(asset('assets')); ?>/img/profiles/avatar-02.jpg"
                                                        alt="User Image" />
                                                </span>
                                            </div>
                                            <div class="list-body">
                                                <span class="message-author">John Doe</span>
                                                <span class="message-time">6 Mar</span>
                                                <div class="clearfix"></div>
                                                <span class="message-content">Lorem ipsum dolor sit amet, consectetur
                                                    adipiscing</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="topnav-dropdown-footer">
                            <a href="chat.html">View all Messages</a>
                        </div>
                    </div>
                </li>

                <li class="nav-item dropdown has-arrow main-drop">
                    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                        <span class="user-img">
                            <?php if(isset(auth()->user()->image)): ?>
                                <img src="<?php echo e(auth()->user()->image); ?>"
                                alt="Profile Picture" />
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets')); ?>/img/user.png"
                                alt="Profile Picture" />
                            <?php endif; ?>
                            <span class="status online"></span></span>
                        <span><?php echo e(auth()->user()->first_name); ?></span>
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="profile.html">My Profile</a>
                        <a class="dropdown-item" href="settings.html">Settings</a>
                        <a class="dropdown-item" href="<?php echo e(route('auth.logout')); ?>">Logout</a>
                    </div>
                </li>
            </ul>

            <div class="dropdown mobile-user-menu">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"
                    aria-expanded="false"><i class="fa-solid fa-ellipsis-vertical"></i></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="profile.html">My Profile</a>
                    <a class="dropdown-item" href="settings.html">Settings</a>
                    <a class="dropdown-item" href="<?php echo e(route('auth.logout')); ?>">Logout</a>
                </div>
            </div>
        </div>

        <div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">

                    <ul class="sidebar-vertical">
                       
                        <?php if (Auth::check() && Auth::user()->hasRole(['admin', 'superadmin', 'businessdevelopment', 'workforce', 'recruitment'])): ?>  
                            <li class="menu-title">
                                <span>Main</span>
                            </li>
                            <li class="<?php if(request()->is('admin/dashboard')): ?> active <?php endif; ?>">
                                <a href="<?php echo e(route('admin.dashboard')); ?>"><i class="la la-dashboard"></i> <span>
                                    Dashboard</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        


                        <li class="menu-title">
                            <span>Management</span>
                        </li>
                        <?php if (Auth::check() && Auth::user()->hasRole(['admin', 'recruitment', 'superadmin'])): ?> 
                            <li class="submenu <?php if(request()->is('admin/employee')): ?> active <?php endif; ?>">
                                <a href="#"><i class="la la-users"></i> <span> Employees</span>
                                    <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(route('admin.employee.all')); ?>" class="<?php if(request()->is('admin/employee')): ?> active <?php endif; ?>">All Employees</a></li>
                                    <li><a href="<?php echo e(route('admin.employee.pending')); ?>" class="<?php if(request()->is('admin/employee/pending')): ?> active <?php endif; ?>">Pending Approval</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->hasRole(['admin', 'businessdevelopment', 'superadmin'])): ?> 
                            <li class="submenu <?php if(request()->is('admin/clients')): ?> active <?php endif; ?>">
                                <a href="#" class="<?php if(request()->is('admin/clients')): ?> active <?php endif; ?>"><i class="la la-user-circle-o"></i> <span> Clients</span>
                                    <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(route('admin.client.all')); ?>" class="<?php if(request()->is('admin/clients')): ?> active <?php endif; ?>">All Clients</a></li>
                                    
                                </ul>
                            </li>
                        <?php endif; ?>
                            
                        <?php if (Auth::check() && Auth::user()->hasRole(['admin', 'workforce', 'superadmin'])): ?> 
                            <li class="<?php if(request()->is('admin/timesheet')): ?> active <?php endif; ?>">
                                <a href="<?php echo e(route('admin.timesheet.all')); ?>" class="<?php if(request()->is('admin/timesheet')): ?> active <?php endif; ?>"><i class="la la-clock-o"></i> <span> Timesheet</span></a>
                            </li>
                            <li class="submenu <?php if(request()->is('admin/shifts')): ?> active <?php endif; ?>">
                                <a href="#"><i class="la la-calendar"></i> <span> Shifts & Schedule</span>
                                    <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(route('admin.shift.all')); ?>" class="<?php if(request()->is('admin/shifts')): ?> active <?php endif; ?>">All Shifts</a></li>
                                    <li><a href="<?php echo e(route('admin.shift.pending')); ?>" class="<?php if(request()->is('admin/shifts/pending')): ?> active <?php endif; ?>">Pending Shifts</a></li>
                                    
                                </ul>
                            </li>
                        <?php endif; ?>
                        <?php if (Auth::check() && Auth::user()->hasRole(['admin', 'superadmin'])): ?> 
                            <li>
                                <a href="#"><i class="la la-briefcase"></i> <span> Leave</span></a>
                            </li>
                            <li class="menu-title">
                                <span>Reports</span>
                            </li>
                            <li class="submenu <?php if(request()->is('admin/reports/employee')): ?> active <?php endif; ?>">
                                <a href="#"><i class="la la-address-card"></i> <span> Reports</span>
                                    <span class="menu-arrow"></span></a>
                                <ul>
                                    
                                    <li><a href="<?php echo e(route('admin.reports.employee')); ?>" class="<?php if(request()->is('admin/reports/employee')): ?> active <?php endif; ?>">Employee Reports </a></li>

                                </ul>
                            </li>
                            <li class="menu-title">
                                <span>Settings</span>
                            </li>
                            <li class="submenu <?php if(request()->is('admin/department')): ?> active <?php endif; ?>">
                                <a href="#" class="<?php if(request()->is('admin/department')): ?> active <?php endif; ?>"><i class="la la-address-card"></i> <span> Departments</span>
                                    <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(route('admin.department.all')); ?>" class="<?php if(request()->is('admin/department')): ?> active <?php endif; ?>">All Departments</a></li>
                                </ul>
                            </li>
                            <li class="submenu <?php if(request()->is('admin/settings/company')): ?> active <?php endif; ?>">
                                <a href="#" class="<?php if(request()->is('admin/settings/company')): ?> active <?php endif; ?>"><i class="la la-asl-interpreting"></i> <span> Company</span>
                                    <span class="menu-arrow"></span></a>
                                <ul>
                                    <li><a href="<?php echo e(route('admin.settings.company')); ?>" class="<?php if(request()->is('admin/settings/company')): ?> active <?php endif; ?>">Company Setup</a></li>
                                </ul>
                            </li>

                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>



        <?php echo $__env->yieldContent('content'); ?>


    </div>


    <script>
        function getAddress(){
            const apiKey = 'AIzaSyApcI-eCy2vhDU9Fx4GmhKsysL8xoZ69oU';
            const postcode = document.getElementById("postcode").value; // Replace with the desired postcode
            
            console.log(postcode.value);

            const apiUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${postcode}&key=${apiKey}`;

            // Make a GET request to the API
            fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'OK' && data.results.length > 0) {
                const formattedAddress = data.results[0].formatted_address;
                address.value = formattedAddress;
                console.log(`Address for ${postcode}: ${formattedAddress}`);
                } else {
                console.log('Unable to retrieve address information.');
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
        }
    </script>

    <script src="<?php echo e(asset('assets')); ?>/js/multipleselect-max.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/filter_by_status.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/add-more-shift.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/total-revenue-bar.js"></script>
    <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/jquery-3.7.0.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/jquery.slimscroll.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/plugins/morris/morris.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/plugins/raphael/raphael.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/chart.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/select2.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/dataTables.bootstrap4.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/moment.min.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/bootstrap-datetimepicker.min.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/layout.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/theme-settings.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/js/greedynav.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/js/app.js"></script>

</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/layouts/admin/app.blade.php ENDPATH**/ ?>