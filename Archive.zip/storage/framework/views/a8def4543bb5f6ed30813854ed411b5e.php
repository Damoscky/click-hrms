<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Shifts</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admin.shift.all')); ?>">All Shifts</a>
                            </li>
                        </ul>
                    </div>
                    <?php if (Auth::check() && Auth::user()->hasRole(['workforce', 'superadmin'])): ?>
                        <div class="col-auto float-end ms-auto">
                            <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_shift">
                                <i class="fa-solid fa-plus"></i> Add Shift</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row filter-row">
                <div class="col-sm-6 col-md-4">
                    <div class="form-group">
                        <input type="text" id="searchInput" class="form-control" placeholder="Search by Type">
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="form-group">
                        <select id="statusFilter" class="form-control">
                            <option value="">Filter by Status</option>
                            <option value="Pending">Pending</option>
                            <option value="Completed">Completed</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="d-grid">
                        <button id="clearFilterBtn" class="btn btn-secondary">Clear Filter</button>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Period</th>
                                    <th>Date</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                    <th>Bank holiday</th>
                                    <th>Total Staff Needed</th>
                                    <th>Total Staff Assigned</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($totalShifts) > 0): ?>
                                    <?php $__currentLoopData = $totalShifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($shift->type); ?></td>
                                            <td><?php echo e($shift->period); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($shift->date)->format('j F, Y')); ?></td>
                                            <td><?php echo e($shift->start_time); ?></td>
                                            <td><?php echo e($shift->end_time); ?></td>
                                            <td><?php echo e($shift->bank_holiday == 1 ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($shift->total_staff); ?></td>
                                            <td><?php echo e($shift->total_staff_assigned); ?></td>
                                            <?php if($shift->status == 'Pending'): ?>
                                                <td>
                                                    <a href="#" class="btn btn-outline-secondary btn-sm"> Pending </a>
                                                </td>
                                            <?php elseif($shift->status == 'Completed'): ?>
                                                <td>
                                                    <a href="#" class="btn btn-outline-success btn-sm"> Completed </a>
                                                </td>
                                            <?php elseif($shift->status == 'In Progress'): ?>
                                                <td>
                                                    <a href="#" class="btn btn-outline-primary btn-sm"> In Progress
                                                    </a>
                                                </td>
                                            <?php elseif($shift->status == 'Assigned'): ?>
                                                <td>
                                                    <a href="#" class="btn btn-outline-primary btn-sm"> Assigned </a>
                                                </td>
                                            <?php elseif($shift->status == 'Cancelled'): ?>
                                                <td>
                                                    <a href="#" class="btn btn-outline-danger btn-sm"> Cancelled </a>
                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <a href="#" class="btn btn-outline-primary" data-bs-toggle="modal"
                                                    data-bs-target="#view_shift-<?php echo e($shift->id); ?>"> View </a>
                                                <?php if($shift->status == 'Pending'): ?>
                                                    <a href="#" class="btn btn-outline-warning" data-bs-toggle="modal"
                                                        data-bs-target="#edit_shift-<?php echo e($shift->id); ?>"> Edit </a>
                                                <?php endif; ?>
                                                <?php if($shift->status == 'Pending' || $shift->status == 'Assigned'): ?>
                                                    <a href="#" class="btn btn-outline-danger" data-bs-toggle="modal"
                                                        data-bs-target="#cancel_shift-<?php echo e($shift->id); ?>"> Cancel </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <div class="modal custom-modal fade" id="cancel_shift-<?php echo e($shift->id); ?>"
                                            role="dialog">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-body">
                                                        <div class="form-header">
                                                            <h3>Cancel Shift?</h3>
                                                            <p>Are you sure you want to cancel this shift?</p>
                                                        </div>
                                                        <div class="modal-btn delete-action">
                                                            <div class="row">
                                                                <div class="row">
                                                                    <div class="col-6">
                                                                        <a href="javascript:void(0);"
                                                                            data-bs-dismiss="modal"
                                                                            class="btn btn-secondary cancel-btn">Cancel</a>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <a href="<?php echo e(route('admin.shift.cancel', base64_encode($shift->id))); ?>"
                                                                            class="btn btn-primary submit-btn continue-btn">Confirm</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal custom-modal fade" id="view_shift-<?php echo e($shift->id); ?>"
                                            role="dialog">
                                            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Employee Assigned for selected shift</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <?php
                                                        $employeeShifts = App\Models\EmployeeShift::where('shift_id', $shift->id)->get();
                                                    ?>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <?php if(count($employeeShifts) > 0): ?>
                                                                <?php $__currentLoopData = $employeeShifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeeShift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-md-4">
                                                                        <div class="card punch-status">
                                                                            <div class="card-body">
                                                                                <h5 class="card-title">
                                                                                    <small class="text-muted"><?php echo e($employeeShift->employee->first_name); ?> <?php echo e($employeeShift->employee->last_name); ?></small>
                                                                                </h5>
                                                                                <div class="punch-det">
                                                                                    <h6>Date Assigned</h6>
                                                                                    <p><?php echo e(Carbon\Carbon::parse($employeeShift->date)->format('j F, Y')); ?> </p>
                                                                                </div>
                                                                                <div class="punch-info">
                                                                                    <div class="punch-hours">
                                                                                            <div class="profile-img-wrap">
                                                                                                <div class="profile-img">
                                                                                                    <a href="#">
                                                                                                        <?php if(isset($employeeShift->employee->employeeRecord->image)): ?>
                                                                                                            <img src="<?php echo e($employeeShift->employee->employeeRecord->image); ?>" 
                                                                                                            alt="<?php echo e($employeeShift->employee->first_name); ?>" />
                                                                                                        <?php else: ?>
                                                                                                            <img src="<?php echo e(asset('assets')); ?>/img/user.jpg" 
                                                                                                            alt="<?php echo e($employeeShift->employee->first_name); ?>" />
                                                                                                        <?php endif; ?>
                                                                                                    </a>
                                                                                                </div>
                                                                                            </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="statistics">
                                                                                    <div class="row">
                                                                                        <div class="col-md-12 col-12 text-center">
                                                                                            <?php if($employeeShift->status == "Pending"): ?>
                                                                                                <p class="btn btn-outline-primary btn-sm"><?php echo e($employeeShift->status); ?></p>
                                                                                            <?php elseif($employeeShift->status == "Cancelled"): ?>
                                                                                                <p class="btn btn-outline-danger btn-sm"><?php echo e($employeeShift->status); ?></p>
                                                                                            <?php elseif($employeeShift->status == "Accepted"): ?>
                                                                                                <p class="btn btn-outline-success btn-sm"><?php echo e($employeeShift->status); ?></p>
                                                                                            <?php elseif($employeeShift->status == "Completed"): ?>
                                                                                                <p class="btn btn-outline-success btn-sm"><?php echo e($employeeShift->status); ?></p>
                                                                                            <?php endif; ?>
                                                                                            
                                                                                        </div>
                                                                                        
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <h3>No Employee Assigned</h3>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="edit_shift-<?php echo e($shift->id); ?>" class="modal custom-modal fade"
                                            role="dialog">
                                            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Edit Shift</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form
                                                            action="<?php echo e(route('admin.shift.update', base64_encode($shift->id))); ?>"
                                                            method="post">
                                                            <?php echo e(csrf_field()); ?>

                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">Type <span
                                                                                class="text-danger">*</span></label>
                                                                        <select required class="form-control"
                                                                            name="type">
                                                                            <option value="<?php echo e($shift->type); ?>">
                                                                                <?php echo e($shift->type); ?></option>
                                                                            <option value="HCA">HCA</option>
                                                                            <option value="Senior HCA">Senior HCA</option>
                                                                            <option value="RGN">RGN</option>
                                                                            <option value="Kitchen Assistant">Kitchen
                                                                                Assistant</option>
                                                                            <option value="Laundry">Laundry/Domestic
                                                                            </option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">Period <span
                                                                                class="text-danger">*</span></label>
                                                                        <select required class="form-control"
                                                                            name="period">
                                                                            <option value="<?php echo e($shift->period); ?>">
                                                                                <?php echo e($shift->period); ?></option>
                                                                            <option value="Full Day">Full Day</option>
                                                                            <option value="Full Night">Full Night</option>
                                                                            <option value="Half Day">Half Day</option>
                                                                            <option value="Half Night">Half Night</option>
                                                                            <option value="Twilight">Twilight</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">Total Staff <span
                                                                                class="text-danger">*</span></label>
                                                                        <div>
                                                                            <input required name="total_staff"
                                                                                value="<?php echo e($shift->total_staff); ?>"
                                                                                class="form-control" type="number" />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">Date <span
                                                                                class="text-danger">*</span></label>
                                                                        <div>
                                                                            <input required name="shift_date"
                                                                                value="<?php echo e($shift->date); ?>"
                                                                                class="form-control" type="date" />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">Start Time
                                                                            <span class="text-danger">*</span></label>
                                                                        <div class="input-group time">
                                                                            <input required name="start_time"
                                                                                value="<?php echo e($shift->start_time); ?>"
                                                                                type="time"
                                                                                class="form-control" /><span
                                                                                class="input-group-text"></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">End Time <span
                                                                                class="text-danger">*</span></label>
                                                                        <div class="input-group time">
                                                                            <input required name="end_time"
                                                                                value="<?php echo e($shift->end_time); ?>"
                                                                                type="time"
                                                                                class="form-control" /><span
                                                                                class="input-group-text"></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <div class="input-block mb-3">
                                                                        <label class="col-form-label">Bank holiday</label>
                                                                        <div class="form-switch">
                                                                            <?php if($shift->bank_holiday == 1): ?>
                                                                                <input name="bank_holiday" checked
                                                                                    type="checkbox"
                                                                                    class="form-check-input"
                                                                                    id="customSwitch1" />
                                                                                <label class="form-check-label"
                                                                                    for="customSwitch1"></label>
                                                                            <?php else: ?>
                                                                                <input name="bank_holiday" type="checkbox"
                                                                                    class="form-check-input"
                                                                                    id="customSwitch1" />
                                                                                <label class="form-check-label"
                                                                                    for="customSwitch1"></label>
                                                                            <?php endif; ?>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="submit-section">
                                                                <button class="btn btn-primary submit-btn">Save</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div id="add_shift" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Request Shift</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('admin.shift.request')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="dynamic-inputs mb-2">
                                <div class="record-set row mb-3">
                                    
                                    <div class="col-sm-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Type <span class="text-danger">*</span></label>
                                            <select required class="form-control" name="type[]">
                                                <option value="">-- Select Type --</option>
                                                <option value="HCA">HCA</option>
                                                <option value="Senior HCA">Senior HCA</option>
                                                <option value="RGN">RGN</option>
                                                <option value="Kitchen Assistant">Kitchen Assistant</option>
                                                <option value="Laundry">Laundry/Domestic</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Period <span
                                                    class="text-danger">*</span></label>
                                            <select required class="form-control" name="period[]">
                                                <option value="">-- Select Period --</option>
                                                <option value="Full Day">Full Day</option>
                                                <option value="Full Night">Full Night</option>
                                                <option value="Half Day">Half Day</option>
                                                <option value="Half Night">Half Night</option>
                                                <option value="Twilight">Twilight</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Client <span
                                                    class="text-danger">*</span></label>
                                            <select class="form-control" name="client_id[]">
                                                <option value="">-- Select Client --</option>
                                                <?php if(count($totalClients) > 0): ?>
                                                    <?php $__currentLoopData = $totalClients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($client->id); ?>">
                                                            <?php echo e($client->clientRecord->company_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Total Staff <span
                                                    class="text-danger">*</span></label>
                                            <div>
                                                <input required name="total_staff[]" class="form-control"
                                                    type="number" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Date <span class="text-danger">*</span></label>
                                            <div>
                                                <input required name="shift_date[]" class="form-control"
                                                    type="date" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Start Time
                                                <span class="text-danger">*</span></label>
                                            <div class="input-group time">
                                                <input required name="start_time[]" type="time"
                                                    class="form-control" /><span class="input-group-text"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">End Time <span
                                                    class="text-danger">*</span></label>
                                            <div class="input-group time">
                                                <input required name="end_time[]" type="time"
                                                    class="form-control" /><span class="input-group-text"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="input-block mb-3">
                                            <label class="col-form-label">Bank holiday</label>
                                            <div class="form-switch">
                                                <input name="bank_holiday[]" type="checkbox" class="form-check-input"
                                                    id="customSwitch1" />
                                                <label class="form-check-label" for="customSwitch1"></label>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-sm-2 mt-2">
                                        <a href="javascript:void(0);" style="display: none;" class="remove-record"
                                            data-index="1"> <i class="fa-solid fa-times"></i> Remove</button>
                                    </div>
                                    <br>
                                </div>
                                <br>
                            </div>
                            <div class="add-more mt-4">
                                <a href="#" class="add-more-button"><i class="fa-solid fa-plus-circle"></i> Add
                                    More</a>
                            </div>
                            <div class="submit-section">
                                <button class="btn btn-primary submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/admin/shift/all-shift.blade.php ENDPATH**/ ?>