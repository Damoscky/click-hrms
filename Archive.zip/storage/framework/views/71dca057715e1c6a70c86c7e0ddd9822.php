<?php $__env->startSection('content'); ?>
    <div class="main-wrapper">
        <div class="account-content">
            <div class="container">

                <div class="account-logo">
                    <a href="admin-dashboard.html"><img src="<?php echo e(asset('assets')); ?>/img/clickhrm-logo.png" alt="<?php echo e(env('APP_NAME')); ?>"></a>
                </div>

                <div class="account-box">
                    <div class="account-wrapper">
                        <h3 class="account-title">Forget Password</h3>
                        <p class="account-subtitle">Please enter your email address</p>

                        <form action="<?php echo e(route('auth.reset-password')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-block mb-4">
                                <label class="col-form-label">Email Address</label>
                                <input class="form-control" type="email" name="email" value="">
                            </div>
                           
                            <div class="input-block mb-4 text-center">
                                <button class="btn btn-primary account-btn" type="submit">Reset Password</button>
                            </div>
                            <div class="account-footer">
                                <p>Remember your password? <a href="<?php echo e(route('index')); ?>">Login</a></p>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pages.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/auth/forget-password.blade.php ENDPATH**/ ?>