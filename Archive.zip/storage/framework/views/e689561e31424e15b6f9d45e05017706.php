<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="page-header">
                        <div class="row">
                            <div class="col-sm-12">
                                <h3 class="page-title">Company Settings</h3>
                            </div>
                        </div>
                    </div>

                    <form action="<?php echo e(route('admin.settings.company.update')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Company Email <span class="text-danger">*</span></label>
                                    <input class="form-control" required name="company_email" type="text" value="<?php echo e(isset($companySetting) ? $companySetting->email : ''); ?>" />
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Contact Number <span class="text-danger">*</span></label>
                                    <input class="form-control" required name="contact_number" value="<?php echo e(isset($companySetting) ? $companySetting->phoneno : ''); ?>" type="text" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Address</label>
                                    <input class="form-control" name="address" value="<?php echo e(isset($companySetting) ? $companySetting->address : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Post Code</label>
                                    <input class="form-control" name="post_code" value="<?php echo e(isset($companySetting) ? $companySetting->post_code : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">City</label>
                                    <input class="form-control" name="city" value="<?php echo e(isset($companySetting) ? $companySetting->city : ''); ?>" type="text" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">IBAN</label>
                                    <input class="form-control" name="iban" value="<?php echo e(isset($companySetting) ? $companySetting->iban : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">BIC (Swift)</label>
                                    <input class="form-control" name="bic" value="<?php echo e(isset($companySetting) ? $companySetting->bic : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Bank Name</label>
                                    <input class="form-control" name="bank_name" value="<?php echo e(isset($companySetting) ? $companySetting->bank_name : ''); ?>" type="text" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Sort Code</label>
                                    <input class="form-control" name="sort_code" value="<?php echo e(isset($companySetting) ? $companySetting->sort_code : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Account Number</label>
                                    <input class="form-control" name="account_number" value="<?php echo e(isset($companySetting) ? $companySetting->account_number : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Account Name</label>
                                    <input class="form-control" name="account_name" value="<?php echo e(isset($companySetting) ? $companySetting->account_name : ''); ?>" type="text" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Standard HCA Rate</label>
                                    <input class="form-control" name="standard_hca" value="<?php echo e(isset($companySetting) ? $companySetting->standard_hca : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Senior HCA Rate</label>
                                    <input class="form-control" name="senior_hca" value="<?php echo e(isset($companySetting) ? $companySetting->senior_hca : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">RGN Rate</label>
                                    <input class="form-control" name="rgn" value="<?php echo e(isset($companySetting) ? $companySetting->rgn : ''); ?>" type="text" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Kitchen Assistant Rate</label>
                                    <input class="form-control" name="kitchen_assistant" value="<?php echo e(isset($companySetting) ? $companySetting->kitchen_assistant : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Laundry / Domestic Rate</label>
                                    <input class="form-control" name="laundry" value="<?php echo e(isset($companySetting) ? $companySetting->laundry : ''); ?>" type="text" />
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Currency </label>
                                    <input class="form-control" name="currency" value="<?php echo e(isset($companySetting) ? $companySetting->currency : ''); ?>" type="text" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                              <div class="input-block mb-3">
                                <label class="col-form-label">Rules & Regulations</label>
                                <textarea class="form-control" name="rules_regulations" id="" cols="30" rows="10"><?php echo e(isset($companySetting) ? $companySetting->rules_regulations : ''); ?></textarea>
                              </div>
                            </div>
                          </div>
                        
                        <div class="submit-section">
                            <button type="submit" class="btn btn-primary submit-btn">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/admin/setting/company-setting.blade.php ENDPATH**/ ?>