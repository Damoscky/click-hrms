<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title">Employee Availablility</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admin.employee.all')); ?>">Employee</a>
                            </li>
                            <li class="breadcrumb-item active">Availability</li>
                        </ul>
                    </div>
                    <div class="col-auto float-end ms-auto">
                        
                        <a href="#" class="btn add-btn m-r-5" data-bs-toggle="modal" data-bs-target="#assign_shift">
                            Assign Shifts</a>
                    </div>
                </div>
            </div>

            <div class="row filter-row">
                <div class="col-sm-6 col-md-4">
                    <div class="input-block mb-3 form-focus">
                        <input type="text" class="form-control floating" />
                        <label class="focus-label">Employee</label>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="input-block mb-3 form-focus select-focus">
                        <select class="select floating">
                            <option>All Department</option>
                            <option value="1">Finance</option>
                            <option value="2">Finance and Management</option>
                            <option value="3">Hr & Finance</option>
                            <option value="4">ITech</option>
                        </select>
                        <label class="focus-label">Department</label>
                    </div>
                </div>
                
                <div class="col-sm-6 col-md-4">
                    <a href="#" class="btn btn-success w-100"> Search </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped custom-table datatable leave-employee-table">
                            <thead>
                                <tr>
                                    <th>Scheduled Shift</th>
                                    <th>Fri 21</th>
                                    <th>Sat 22</th>
                                    <th>Sun 23</th>
                                    <th>Mon 24</th>
                                    <th>Tue 25</th>
                                    <th>Wed 26</th>
                                    <th>Thu 27</th>
                                    <th>Fri 28</th>
                                    <th>Sat 29</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <h2 class="table-avatar">
                                            <a href="profile.html" class="avatar"><img
                                                    src="<?php echo e(asset('assets')); ?>/img/user.png" alt="User Image" /></a>
                                            <a href="profile.html">Isreal Doe </a>
                                        </h2>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <h2>
                                                <a href="#" data-bs-toggle="modal" data-bs-target="#edit_schedule"
                                                    class="green-border">
                                                    <span class="username-info m-b-10">6:30 am - 9:30 pm ( 14 hrs 15
                                                        mins)</span>
                                                    <span class="userrole-info">Web Designer - SMARTHR</span>
                                                </a>
                                            </h2>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <h2>
                                                <a href="#" data-bs-toggle="modal" data-bs-target="#edit_schedule"
                                                    class="green-border">
                                                    <span class="username-info m-b-10">6:30 am - 9:30 pm ( 14 hrs 15
                                                        mins)</span>
                                                    <span class="userrole-info">Web Designer - SMARTHR</span>
                                                </a>
                                            </h2>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-add-shedule-list">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#add_schedule">
                                                <span><i class="fa-solid fa-plus"></i></span>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="assign_shift" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Assign Shift</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Employee Name <span
                                            class="text-danger">*</span></label>
                                    <select class="select">
                                        <option value="">Select</option>
                                        <option value="1">Richard Miles</option>
                                        <option value="2">John Smith</option>
                                        <option value="4">Wilmer Deluna</option>
                                        <option value="3">Mike Litorus</option>
                                        <option value="4">Wilmer Deluna</option>
                                        <option value="4">Wilmer Deluna</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Shifts <span
                                            class="text-danger">*</span></label>
                                    <select class="select">
                                        <option value="">-- Select Shift --</option>
                                        <option value="1">Richard Miles - First Health Care</option>
                                        <option value="2">John Smith - Click Health Care</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Contact Number <span
                                            class="text-danger">*</span></label>
                                    <div class="input-group time">
                                        <input class="form-control" type="text" name="contact_number" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Rules & Regulations </label>
                                    <textarea class="form-control"></textarea>
                                </div>
                            </div>
                            
                            <div class="col-sm-12">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Notify Client </label>
                                    <div class="form-switch">
                                        <input type="checkbox" class="form-check-input" id="customSwitch1"
                                            checked="" />
                                        <label class="form-check-label" for="customSwitch1"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div id="add_schedule" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Availablility || John Doe</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Employee Name</label>
                                    <div>
                                        <input class="form-control" disabled value="John Doe" type="text" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Employee Code</label>
                                    <div>
                                        <input class="form-control" disabled value="EMP-0984" type="text" />
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Date</label>
                                    <div class="cal-icon">
                                        <input class="form-control datetimepicker" type="text" />
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Start Time
                                        <span class="text-danger">*</span></label>
                                    <div class="input-group time">
                                        <input class="form-control timepicker" /><span class="input-group-text"><i
                                                class="fa-regular fa-clock"></i></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">End Time <span class="text-danger">*</span></label>
                                    <div class="input-group time">
                                        <input class="form-control timepicker" /><span class="input-group-text"><i
                                                class="fa-regular fa-clock"></i></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="input-block mb-3">
                                    <label class="col-form-label">Notify Employee </label>
                                    <div class="form-check form-switch">
                                        <input type="checkbox" class="form-check-input" id="customSwitch1"
                                            checked="" />
                                        <label class="form-check-label" for="customSwitch1"></label>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div class="submit-section">
                            <button class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/admin/employee/availability.blade.php ENDPATH**/ ?>