<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title">Employee Report</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                            </li>
                            <li class="breadcrumb-item active">Employee Report</li>
                        </ul>
                    </div>

                    <div class="col-auto">
                        <?php
                            $queryParam = http_build_query(['records' => $records]);

                            $url = route('admin.reports.export.employee') . '?' . $queryParam;
                        ?>
                        <a href="<?php echo e($url); ?>" class="btn btn-primary">Export</a>
                    </div>
                </div>
            </div>

            <form action="<?php echo e(route('admin.reports.generate.employee')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="row filter-row mb-4">
                    <div class="col-sm-6 col-md-3">
                        <div class="input-block mb-3 form-focus select-focus">
                            <select name="department" class="select floating">
                                <option value="All">All Department</option>
                                <?php if(count($departments) > 0): ?>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <label class="focus-label">Department</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="input-block mb-3 form-focus">
                            <div class="cal-icon">
                                <input name="start_date" class="form-control floating datetimepicker" type="text" />
                            </div>
                            <label class="focus-label">From</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="input-block mb-3 form-focus">
                            <div class="cal-icon">
                                <input name="end_date" class="form-control floating datetimepicker" type="text" />
                            </div>
                            <label class="focus-label">To</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-success"> Generate </button>
                        </div>
                    </div>
                </div>
            </form>

            <?php if(count($records) > 0): ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table mb-0 datatable">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Employee ID</th>
                                        <th>Email</th>
                                        <th>Department</th>
                                        <th>Resumption Date</th>
                                        <th>DOB</th>
                                        <th>Martial Status</th>
                                        <th>Gender</th>
                                        <th>Address</th>
                                        <th>State</th>
                                        <th>Post Code</th>
                                        <th>Nationality</th>
                                        <th>Religion</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <h2 class="table-avatar">
                                                    <?php if(isset($record->employeeRecord->image)): ?>
                                                        <a href="#" class="avatar"><img
                                                            src="<?php echo e($record->employeeRecord->image); ?>" alt="<?php echo e($record->first_name); ?>" /></a>

                                                    <?php else: ?>
                                                        <a href="#" class="avatar"><img
                                                            src="<?php echo e(asset('assets')); ?>/img/user.png"
                                                            alt="User Image" /></a>
                                                    <?php endif; ?>
                                                    <a href="#" class="text-primary">
                                                        <?php echo e($record->first_name); ?> <?php echo e($record->last_name); ?>

                                                        </a>
                                                </h2>
                                            </td>
                                            <td><span><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->employee_id : ''); ?></span></td>
                                            <td class="text-info">
                                                <a href="mailto:<?php echo e($record->email); ?>"
                                                    class="__cf_email__"
                                                    data-cfemail="d6bcb9beb8a5bbbfa2be96b3aeb7bba6bab3f8b5b9bb"><?php echo e($record->email); ?></a>
                                            </td>
                                            <td><?php echo e(isset($record->employeeRecord->department) ? $record->employeeRecord->department->name : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord->resumption_date) ? \Carbon\Carbon::parse($record->employeeRecord->resumption_date)->format('j F, Y') : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord->date_of_birth) ? \Carbon\Carbon::parse($record->employeeRecord->date_of_birth)->format('j F, Y') : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->marital_status : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->gender : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->address : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->state : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->post_code : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->nationality : ''); ?></td>
                                            <td><?php echo e(isset($record->employeeRecord) ? $record->employeeRecord->religion : ''); ?></td>
                                            <?php if($record->status == "Approved"): ?>
                                                <td>
                                                    <button class="btn btn-outline-success btn-sm">
                                                        <?php echo e($record->status); ?>

                                                    </button>
                                                </td>

                                            <?php elseif($record->status == "Pending"): ?>
                                                <td>
                                                    <button class="btn btn-outline-warning btn-sm">
                                                        <?php echo e($record->status); ?>

                                                    </button>
                                                </td>

                                            <?php elseif($record->status == "Declined"): ?>
                                                <td>
                                                    <button class="btn btn-outline-danger btn-sm">
                                                        <?php echo e($record->status); ?>

                                                    </button>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/admin/report/employee-report.blade.php ENDPATH**/ ?>