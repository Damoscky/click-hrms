<!DOCTYPE html>
<html>
<head>
    <style>
        .watermark {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            opacity: 0.3;
            font-size: 24px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="watermark">This is the Watermark Text</div>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/click-hrms/resources/views/client/pdf/watermark.blade.php ENDPATH**/ ?>