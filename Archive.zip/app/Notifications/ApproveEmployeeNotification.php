<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ApproveEmployeeNotification extends Notification
{
    use Queueable;

    public $data;

    /**
     * Create a new notification instance.
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        $data = $this->data;
        return (new MailMessage)
                ->greeting('Congratulations '. $data['first_name'].'!')
                ->subject("Application Approved - ". env('APP_NAME'))
                ->line("Your application and documentation has been approved on ". env('APP_NAME'))
                ->line("Welcome to the team! We are thrilled to have you on board. We believe that you’re going to be a valuable asset to our company, and we can’t wait to see all that you accomplish.")
                ->line("Once again, Congratulations on being part of our dynamic team!" );
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
